import { Component, OnInit } from '@angular/core';
import { Topic } from '../model/topicmodel';
import topics from '../model/topicslist';
import { TopicService } from '../service/topic.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-topiclist',
  templateUrl: './topiclist.component.html',
  styleUrls: ['./topiclist.component.css']
})
export class TopiclistComponent implements OnInit {
  
  listoftopics:Topic[] = [];
  categories:string[]=['oops', 'web','lang'];
  cat:string='all';
  constructor(private service:TopicService,
    private router:Router, private route:ActivatedRoute) { 
    this.listoftopics = topics;
  }
  ngOnInit(): void {
    this.service.getTopics()
    .subscribe((response:Topic[])=>{
      this.listoftopics = response
      console.log('resp ',this.listoftopics)
      console.log(this.listoftopics)
      console.log(response)
    });  
  }
  onselect(topic){
    console.log(topic.topicid)
    this.router.navigate([topic.topicid],{relativeTo:this.route})
  }
}
