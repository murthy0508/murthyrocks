export class Topic{
    constructor(public topicid:number,
        public topicname:string,
       public description:string,
       public category?:string){}
}
//topicform.html
//topic.html