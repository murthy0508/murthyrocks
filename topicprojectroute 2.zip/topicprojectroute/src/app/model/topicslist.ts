import {Topic} from './topicmodel';
let topics=[
    new Topic(1,'java','Trending language','oops'),
    new Topic(2,'c','First choice for compilers','lang'),
    new Topic(3,'python','Machine learning language','oops'),
    new Topic(4,'java','New features for MVC','oops'),
    new Topic(5,'html5','New features for web development','web')
]

export default topics;