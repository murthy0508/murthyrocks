import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Topic } from '../model/topicmodel';
import { TopicService } from '../service/topic.service';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-topicform',
  templateUrl: './topicform.component.html',
  styleUrls: ['./topicform.component.css']
})
export class TopicformComponent implements OnInit {
  @Output()
  topicCreated:EventEmitter<any> = new EventEmitter();
  user:User;
  topic:Topic;
  categories:string[]=['oops','web','lang']
  constructor(private service:TopicService, 
    private router:Router,
    private route:ActivatedRoute) {
    this.topic= new Topic(0,'','','');
    this.user= new User('');
  }
  submit(form)
  {
    console.log(form)
    console.log(this.topic);
    //this.topicCreated.emit(form);
    this.service.addTopic(this.topic)
    .subscribe((resp)=>
    {
      console.log(resp)
      this.router.navigate(['../list'],{relativeTo:this.route})
    },
    (err)=>this.router.navigate(['/error'])
    );

  }
  ngOnInit(): void {
  }
}

class User{
  constructor(public username:string){}
}