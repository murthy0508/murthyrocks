import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Topic } from '../model/topicmodel';
import { TopicService } from '../service/topic.service';

@Component({
  selector: 'app-topicdetail',
  templateUrl: './topicdetail.component.html',
  styleUrls: ['./topicdetail.component.css']
})
export class TopicdetailComponent implements OnInit {

  topic:Topic
  constructor(private route:ActivatedRoute, private service:TopicService) { 
    this.route.paramMap.subscribe(
      (params:ParamMap)=>{
        console.log(params);
        this.service.getTopicById(parseInt(params.get('id')))
        .subscribe((response:Topic)=> this.topic = response)
      }
    )
  }

  ngOnInit(): void {
  }

}
