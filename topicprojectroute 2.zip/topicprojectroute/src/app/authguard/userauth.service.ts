import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class UserCanActivate implements CanActivate{

  constructor(private service:UserService, private router:Router){}
  canActivate()
  {
    if(this.service.isLoggedIn())
    {
      console.log('can activate working...')
      return true;
    }
    else{
      console.log('can activate else')
      this.router.navigate(['/login'])
      return false;
    }
  }
}
