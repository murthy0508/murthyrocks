package com.lti.demos.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;
import org.hibernate.tuple.entity.EntityMetamodel.GenerationStrategyPair;
import org.springframework.boot.autoconfigure.batch.BatchDataSource;

@Entity

public class Topic {
	@Id
	private Integer topicid;
	
	private String topicname;
	
	private String description;
	public Topic() {
		System.out.println("Topic default constructor");
	}
	
	public Topic(Integer topicid, String topicname, String description) {
		super();
		this.topicid = topicid;
		this.topicname = topicname;
		this.description = description;
	}

	public Integer getTopicid() {
		return topicid;
	}
	public void setTopicid(Integer topicid) {
		System.out.println("topic id set");
		this.topicid = topicid;
	}
	public String getTopicname() {
		return topicname;
	}
	public void setTopicname(String topicname) {
		System.out.println("set topic name");
		this.topicname = topicname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Topic [topicid=" + topicid + ", topicname=" + topicname + ", description=" + description + "]";
	}
	


	
	
}
