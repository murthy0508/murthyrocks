package com.lti.demos.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.lti.demos.model.Topic;
import com.lti.demos.service.TopicService;

@RestController// Controller and ResponseBody
@RequestMapping("/topics")
public class TopicResource {
	
	/*
	 * TopicResource - producer
	 * Postman - consumer
	 * consumer -> POST topic{} XML Content-type = 
	 * consumer -> Fetch/ GET Accept ->  
	 */
	@Autowired
	TopicService topicService;
	
	@GetMapping(produces = {"application/json","application/xml"})
	public List<Topic> getAllTopics()
	{
		return this.topicService.getAllTopics();
	}
	//localhost:8080/topics/1/username/shalini
	@GetMapping("/{id}/username/{username}")
	public Topic getTopicById(@PathVariable("id") int topicid, @PathVariable String username)
	{
		return this.topicService.getTopic(topicid);
	}
	@PostMapping(consumes = {"application/json","application/xml"}
	,produces = {"application/json","application/xml"})
	@ResponseStatus(code = HttpStatus.CREATED)
	public Topic insert(@RequestBody Topic topic)
	{
		return topicService.addTopic(topic);
	}
	@PutMapping
	@ResponseStatus(code = HttpStatus.ACCEPTED)
	public Topic update(@RequestBody Topic topic)
	{
		return topicService.updateTopic(topic);
	}
	@DeleteMapping("/{id}")
	//@ResponseStatus(code = HttpStatus.FOUND)
	public ResponseEntity<String> delete(@PathVariable int id)
	{
		ResponseEntity<String> entity = null;
		if(topicService.deleteTopic(id))
			entity = new ResponseEntity<String>("Deleted", HttpStatus.FOUND);
		else
			entity = new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		return entity;
	}
	
}




