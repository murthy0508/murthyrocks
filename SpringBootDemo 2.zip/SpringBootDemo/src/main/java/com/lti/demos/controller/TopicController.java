package com.lti.demos.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.demos.model.Topic;
import com.lti.demos.service.TopicService;


//CAN EVERYONE PLEASE MUTE?

@Controller
//@RequestMapping("/topics")
public class TopicController {

	@Autowired
	TopicService service;
	@RequestMapping("/greet")
	public @ResponseBody String message()
	{
		return "<h1>Good Morning!!!</h1>";
	}
	
	@RequestMapping("/")
	public String display()
	{
		return "index";
	}
	@RequestMapping("/edit/{id}")
	public @ResponseBody String edit(@PathVariable("id") int id)
	{
		return "Id "+id;
	}
	@RequestMapping("/list")
	
	public String listoftopics(Map<String, List<Topic>> map)
	{
		List<Topic> topics = new ArrayList<Topic>();
		topics = this.service.getAllTopics();
		 map.put("topics", topics);
		return "topics";
	}
	@RequestMapping(path = "/add", method = RequestMethod.POST)
	public String addTopic(Topic topic)
	{
		//System.out.println(topic.getTopicname().toUpperCase());
		this.service.addTopic(topic);
		return "redirect:/list";
	}
}
