package com.lti.demos.database;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lti.demos.model.Topic;

//@Repository
public interface TopicRepository extends CrudRepository<Topic, Integer>{

	public List<Topic> findBytopicname(String name);
	//public List<Topic> findBytopicname(String name, int id);
	
	@Query(nativeQuery = true, value = "select * from topic where topicname=?1")
	public Topic getTopicByName(String name);
}
