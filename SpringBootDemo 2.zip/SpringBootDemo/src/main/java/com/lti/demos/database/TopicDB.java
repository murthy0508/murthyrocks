package com.lti.demos.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

//@Repository

public class TopicDB {
	
//	@Autowired
	private String username;
//	@Autowired
	private String email;
	
//	@Autowired
	private JdbcTemplate template;
	public TopicDB() {
		System.out.println("TopicDb template "+template);
	}
	public JdbcTemplate getTemplate() {
		System.out.println("username "+username);
		System.out.println("email "+email);
		return template;
	}
	
}
