package com.lti.demos;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.lti.demos.model.Topic;

//@Configuration
//@PropertySource("classpath:db.properties")
public class COnfig {
	
	public COnfig() {
		System.out.println("configuration");
	}
	
	@Autowired
	private Environment env;
	
	@Bean(name = "username")
	public String getName()
	{
		System.out.println(env.getProperty("name"));
		return env.getProperty("name");
	}
	@Bean(name = "email")
	public String getEmail()
	{
		System.out.println(env.getProperty("name"));
		return "shalini@gmaikl.com";
	}
//	@Bean(name = "email")
//	public TopicService getTopic()
//	{
//		System.out.println(env.getProperty("name"));
//		return new TopicService();
//	}
	
}
