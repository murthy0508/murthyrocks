package com.lti.demos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.lti.demos.database.TopicDB;
import com.lti.demos.model.Topic;
import com.lti.demos.service.TopicService;

@SpringBootApplication
//@PropertySource("classpath:db.properties")
public class SpringBootDemoApplication {

//	@Autowired
//	private Environment env;
	
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(SpringBootDemoApplication.class, args);
		TopicService service = ctx.getBean(TopicService.class);
//		System.out.println(service.getAllTopics());
//		service.addTopic(new Topic(2,"CSS","Web Styling"));
//		service.addTopic(new Topic(3,"CSS","Web Presentation"));
//		service.addTopic(new Topic(4,"CSS","Web Colors"));
//		System.out.println(service.getAllTopics());
//		System.out.println(service.getTopicsByName("CSS"));
		System.out.println(service.getTopicByName("HTML"));
	}

//	@Bean(name = "email")
//	public String getEmail()
//	{
//		System.out.println(env.getProperty("name"));
//		return "shalini@gmaikl.com";
//	}
}
