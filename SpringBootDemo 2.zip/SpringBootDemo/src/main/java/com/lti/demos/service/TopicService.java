package com.lti.demos.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.demos.database.TopicRepository;
import com.lti.demos.model.Topic;

@Service
public class TopicService {

	@Autowired
	private TopicRepository topicRepository;

	public List<Topic> getAllTopics()
	{	
		System.out.println("message "+message);
		List<Topic> topics = new ArrayList<>();
		topicRepository.findAll().forEach(topics::add);
		//topicRepository.findAll().forEach(topic->topics.add(topic));
		return topics;
	}
	public Topic getTopic(int id) {
		return topicRepository.findById(id).get();
	}
	
	public Topic addTopic(Topic topic)
	{
		return topicRepository.save(topic);
	}
	public Topic updateTopic(Topic topic)
	{
		//updates the topic if it exists else it does an insert
		return topicRepository.save(topic);
	}
	public boolean deleteTopic(int id)
	{
		if(topicRepository.existsById(id))
		{
			topicRepository.deleteById(id);
			return true;
		}
		return false;
	}
	@Value("${message}")
	private String message;
	
	
	public TopicRepository getTopicRepository() {
		return topicRepository;
	}
	public void setTopicRepository(TopicRepository topicRepository) {
		this.topicRepository = topicRepository;
	}
	public List<Topic> getTopicsByName(String name)
	{
		System.out.println("message "+message);
		List<Topic> topics = new ArrayList<>();
		topicRepository.findBytopicname(name).forEach(topics::add);
		//topicRepository.findAll().forEach(topic->topics.add(topic));
		return topics;
	}
	public Topic getTopicByName(String name) {
		return topicRepository.getTopicByName(name);
	}

}
